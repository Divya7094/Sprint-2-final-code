namespace WisVestAPI.Models.Matrix
{
    public class SubAllocationMatrix
    {
        public Dictionary<string, Dictionary<string, Dictionary<string, double>>> Matrix { get; set; }
    }
}


